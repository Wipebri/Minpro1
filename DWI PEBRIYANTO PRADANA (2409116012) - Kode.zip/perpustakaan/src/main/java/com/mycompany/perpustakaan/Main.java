/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.perpustakaan;

/**
 *
 * @author User
 */
import java.util.ArrayList;
import java.util.Scanner;

class Buku {
    private String judul;
    private String pengarang;
    private int tahunTerbit;
    private String isbn;
    private int jumlahStok;

    // Constructor
    public Buku(String judul, String pengarang, int tahunTerbit, String isbn, int jumlahStok) {
        this.judul = judul;
        this.pengarang = pengarang;
        this.tahunTerbit = tahunTerbit;
        this.isbn = isbn;
        this.jumlahStok = jumlahStok;
    }

    // Getter & Setter
    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getPengarang() {
        return pengarang;
    }

    public void setPengarang(String pengarang) {
        this.pengarang = pengarang;
    }

    public int getTahunTerbit() {
        return tahunTerbit;
    }

    public void setTahunTerbit(int tahunTerbit) {
        this.tahunTerbit = tahunTerbit;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getJumlahStok() {
        return jumlahStok;
    }

    public void setJumlahStok(int jumlahStok) {
        this.jumlahStok = jumlahStok;
    }
    
}

class Perpustakaan {
    private ArrayList<Buku> daftarBuku = new ArrayList<>();

    // Create
    public void tambahBuku(Buku b) {
        daftarBuku.add(b);
        System.out.println("Buku telah ditambahkan!");
    }

    // Read
    public void tampilkanDaftarBuku() {
        if (daftarBuku.isEmpty()) {
            System.out.println("belum ada buku di dalam perpustakaan.");
            return;
        }
        for (Buku b : daftarBuku) {
            System.out.println("Judul: " + b.getJudul());
            System.out.println("Pengarang: " + b.getPengarang());
            System.out.println("Tahun Terbit: " + b.getTahunTerbit());
            System.out.println("ISBN: " + b.getIsbn());
            System.out.println("Stok Buku: " + b.getJumlahStok());
            System.out.println("----------------------------");
        }
    }

    // method untuk memperbarui
    public void updateStok(String isbn, int stokBaru) {
        for (Buku b : daftarBuku) {
            if (b.getIsbn().equals(isbn)) {
                b.setJumlahStok(stokBaru);
                System.out.println("Stok buku berhasil diperbarui.");
                return;
            }
        }
        System.out.println("Buku dengan ISBN " + isbn + " tidak ditemukan.");
    }

    // methode untuk menghapus
    public void hapusBuku(String isbn) {
        for (Buku b : daftarBuku) {
            if (b.getIsbn().equals(isbn)) {
                daftarBuku.remove(b);
                System.out.println("Buku berhasil dihapus.");
                return;
            }
        }
        System.out.println("Buku dengan ISBN " + isbn + " tidak ditemukan.");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Perpustakaan perpustakaan = new Perpustakaan();
        int pilihan = 0;

        while (pilihan != 5) {
            System.out.println("\n=== MENU PERPUSTAKAAN ===");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Tampilkan Daftar Buku");
            System.out.println("3. Update Stok Buku");
            System.out.println("4. Hapus Buku");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = input.nextInt();
            input.nextLine();

            if (pilihan == 1) {
                System.out.println("\n=== MENAMBAHKAN BUKU ===");
                System.out.print("Judul: ");
                String judul = input.nextLine();
                System.out.print("Pengarang: ");
                String pengarang = input.nextLine();
                System.out.print("Tahun Terbit: ");
                int tahun = input.nextInt();
                input.nextLine();
                System.out.print("ISBN: ");
                String isbn = input.nextLine();
                System.out.print("Jumlah Stok: ");
                int stok = input.nextInt();

                Buku b = new Buku(judul, pengarang, tahun, isbn, stok);
                perpustakaan.tambahBuku(b);

            } else if (pilihan == 2) {
                System.out.println("\n=== Daftar Buku ===");
                perpustakaan.tampilkanDaftarBuku();

            } else if (pilihan == 3) {
                System.out.println("\n=== MEMPERBARUI BUKU ===");
                System.out.print("Masukkan ISBN buku yang akan diperbarui: ");
                String isbnUpdate = input.nextLine();
                System.out.print("Masukkan stok baru: ");
                int stokBaru = input.nextInt();
                perpustakaan.updateStok(isbnUpdate, stokBaru);

            } else if (pilihan == 4) {
                System.out.println("\n=== MENGHAPUS BUKU ===");
                System.out.print("Masukkan ISBN buku yang akan dihapus: ");
                String isbnHapus = input.nextLine();
                perpustakaan.hapusBuku(isbnHapus);

            } else if (pilihan == 5) {
                System.out.println("Terima kasih sudah berkunjung...");

            } else {
                System.out.println("Pilihan tidak ada!");
            }
        }

        input.close();
    }
}
